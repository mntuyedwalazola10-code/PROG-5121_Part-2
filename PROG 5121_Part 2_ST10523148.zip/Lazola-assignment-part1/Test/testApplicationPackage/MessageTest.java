package testApplicationPackage;

import mainApplicationPackage.Message;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * MessageTest - JUnit test class.
 */
public class MessageTest {

    @Test
    public void testMessageLengthSuccess() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Hi Mike, can you join us for dinner tonight?"
                );

        assertTrue(
                obj.checkMessageLength()
        );
    }

    @Test
    public void testMessageLengthFailure() {

        String large_message =
                "A".repeat(260);

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        large_message
                );

        assertFalse(
                obj.checkMessageLength()
        );
    }

    @Test
    public void testRecipientCellCorrect() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing recipient"
                );

        assertEquals(
                1,
                obj.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientCellIncorrect() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "0812345678",
                        "Testing recipient"
                );

        assertEquals(
                0,
                obj.checkRecipientCell()
        );
    }

    @Test
    public void testMessageHashGenerated() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Hi Mike, can you join us for dinner tonight?"
                );

        assertEquals(
                "00:0:HITONIGHT?",
                obj.getMessageHash()
        );
    }

    @Test
    public void testMessageIDCreated() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Test"
                );

        assertTrue(
                obj.checkMessageID()
        );
    }

    @Test
    public void testSendMessageOption() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing send"
                );

        assertEquals(
                "Message successfully sent.",
                obj.sentMessage(1)
        );
    }

    @Test
    public void testDisregardMessageOption() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing disregard"
                );

        assertEquals(
                "Press 0 to delete message.",
                obj.sentMessage(2)
        );
    }

    @Test
    public void testStoreMessageOption() {

        Message obj =
                new Message(
                        "0012345678",
                        0,
                        "+27718693002",
                        "Testing store"
                );

        assertEquals(
                "Message successfully stored.",
                obj.sentMessage(3)
        );
    }
}