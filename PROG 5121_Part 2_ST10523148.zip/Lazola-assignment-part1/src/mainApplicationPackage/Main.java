package mainApplicationPackage;

import java.util.Random;
import java.util.Scanner;

/**
 * Main class for console application.
 */
public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter first name: ");
        String first = sc.nextLine();

        System.out.print("Enter last name: ");
        String last = sc.nextLine();

        System.out.print("Enter username: ");
        String user = sc.nextLine();

        System.out.print("Enter password: ");
        String pass = sc.nextLine();

        System.out.print("Enter South African cell phone number (include +27): ");
        String phone = sc.nextLine();

        Login app =
                new Login(first, last, user, pass, phone);

        String result =
                app.registerUser();

        System.out.println(result);

        if (app.checkUserName()
                && app.checkPasswordComplexity()
                && app.checkCellPhoneNumber()) {

            System.out.println();
            System.out.println("===== LOGIN =====");

            System.out.print("Enter username: ");
            String loginUser =
                    sc.nextLine();

            System.out.print("Enter password: ");
            String loginPass =
                    sc.nextLine();

            System.out.println(
                    app.returnLoginStatus(
                            loginUser,
                            loginPass
                    )
            );

            if (app.loginUser(
                    loginUser,
                    loginPass)) {

                System.out.println();
                System.out.println(
                        "Welcome to QuickChat."
                );

                int menu_choice = 0;

                while (menu_choice != 3) {

                    System.out.println();
                    System.out.println("===== QUICKCHAT MENU =====");
                    System.out.println("1) Send Messages");
                    System.out.println("2) Show recently sent messages");
                    System.out.println("3) Quit");

                    System.out.print(
                            "Choose option: "
                    );

                    menu_choice =
                            sc.nextInt();

                    sc.nextLine();

                    switch (menu_choice) {

                        case 1:

                            System.out.print(
                                    "How many messages would you like to send? "
                            );

                            int total_messages =
                                    sc.nextInt();

                            sc.nextLine();

                            for (int counter = 1;
                                 counter <= total_messages;
                                 counter++) {

                                System.out.println();
                                System.out.println(
                                        "===== MESSAGE "
                                                + counter
                                                + " ====="
                                );

                                String generated_message_id =
                                        generateMessageID();

                                System.out.println(
                                        "Generated Message ID: "
                                                + generated_message_id
                                );

                                System.out.print(
                                        "Enter recipient number: "
                                );

                                String recipient =
                                        sc.nextLine();

                                System.out.print(
                                        "Enter message: "
                                );

                                String text_message =
                                        sc.nextLine();

                                Message message_object =
                                        new Message(
                                                generated_message_id,
                                                counter,
                                                recipient,
                                                text_message
                                        );

                                if (!message_object.checkMessageID()) {

                                    System.out.println(
                                            "Message ID invalid."
                                    );

                                    continue;
                                }

                                if (message_object.checkRecipientCell() == 1) {

                                    System.out.println(
                                            "Cell phone number successfully captured."
                                    );

                                } else {

                                    System.out.println(
                                            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again."
                                    );

                                    continue;
                                }

                                if (message_object.checkMessageLength()) {

                                    System.out.println(
                                            "Message ready to send."
                                    );

                                } else {

                                    int exceeded_characters =
                                            text_message.length() - 250;

                                    System.out.println(
                                            "Message exceeds 250 characters by "
                                                    + exceeded_characters
                                                    + ", please reduce the size."
                                    );

                                    continue;
                                }

                                System.out.println();
                                System.out.println("1) Send Message");
                                System.out.println("2) Disregard Message");
                                System.out.println("3) Store Message");

                                System.out.print(
                                        "Enter selection: "
                                );

                                int selected_option =
                                        sc.nextInt();

                                sc.nextLine();

                                System.out.println(
                                        message_object.sentMessage(
                                                selected_option
                                        )
                                );

                                System.out.println();
                                System.out.println(
                                        "===== MESSAGE DETAILS ====="
                                );

                                System.out.println(
                                        message_object.printMessage()
                                );
                            }

                            System.out.println();
                            System.out.println(
                                    "Total messages sent: "
                                            + Message.returnTotalMessages()
                            );

                            break;

                        case 2:

                            System.out.println(
                                    "Coming Soon."
                            );

                            break;

                        case 3:

                            System.out.println(
                                    "Exiting QuickChat."
                            );

                            break;

                        default:

                            System.out.println(
                                    "Invalid option selected."
                            );
                    }
                }
            }
        }

        sc.close();
    }

    /**
     * Generate random 10 digit message ID.
     */
    public static String generateMessageID() {

        Random random_number =
                new Random();

        long generated_number =
                1000000000L
                        + (long)(
                        random_number.nextDouble()
                                * 9000000000L
                );

        return String.valueOf(
                generated_number
        );
    }
}