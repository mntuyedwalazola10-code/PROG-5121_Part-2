package mainApplicationPackage;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Message class manages all QuickChat messaging features.
 */
public class Message {

    private String message_id;
    private int message_number;
    private String recipient_cell;
    private String message_text;
    private String message_hash;

    private static int total_messages_sent = 0;

    /**
     * Constructor for Message object.
     */
    public Message(String message_id,
                   int message_number,
                   String recipient_cell,
                   String message_text) {

        this.message_id = message_id;
        this.message_number = message_number;
        this.recipient_cell = recipient_cell;
        this.message_text = message_text;

        this.message_hash = createMessageHash();
    }

    /**
     * Validate message ID length.
     */
    public boolean checkMessageID() {

        return message_id.length() == 10;
    }

    /**
     * Validate recipient number.
     */
    public int checkRecipientCell() {

        if (recipient_cell.matches("^\\+27\\d{9}$")) {
            return 1;
        }

        return 0;
    }

    /**
     * Validate message length.
     */
    public boolean checkMessageLength() {

        return message_text.length() <= 250;
    }

    /**
     * Create message hash.
     */
    public String createMessageHash() {

        String[] split_message =
                message_text.trim().split("\\s+");

        String first_word =
                split_message[0].toUpperCase();

        String last_word =
                split_message[
                        split_message.length - 1
                ].toUpperCase();

        return message_id.substring(0, 2)
                + ":"
                + message_number
                + ":"
                + first_word
                + last_word;
    }

    /**
     * Process message option selected by user.
     */
    public String sentMessage(int option_selected) {

        switch (option_selected) {

            case 1:

                total_messages_sent++;

                return "Message successfully sent.";

            case 2:

                return "Press 0 to delete message.";

            case 3:

                storeMessage();

                return "Message successfully stored.";

            default:

                return "Invalid option selected.";
        }
    }

    /**
     * Display full message details.
     */
    public String printMessage() {

        return "Message ID: " + message_id
                + "\nMessage Hash: " + message_hash
                + "\nRecipient: " + recipient_cell
                + "\nMessage: " + message_text;
    }

    /**
     * Return total number of sent messages.
     */
    public static int returnTotalMessages() {

        return total_messages_sent;
    }

    /**
     * Store message into JSON file.
     */
    public void storeMessage() {

        try {

            FileWriter json_file =
                    new FileWriter(
                            "storedMessages.json",
                            true
                    );

            json_file.write("{\n");
            json_file.write("\"MessageID\": \"" + message_id + "\",\n");
            json_file.write("\"MessageHash\": \"" + message_hash + "\",\n");
            json_file.write("\"Recipient\": \"" + recipient_cell + "\",\n");
            json_file.write("\"Message\": \"" + message_text + "\"\n");
            json_file.write("}\n");

            json_file.close();

        } catch (IOException e) {

            System.out.println(
                    "Error storing message."
            );
        }
    }

    public String getMessageHash() {

        return message_hash;
    }
}