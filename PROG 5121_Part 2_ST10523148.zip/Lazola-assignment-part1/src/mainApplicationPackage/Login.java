
package mainApplicationPackage;

/**
 * Login class - User registration and authentication implementation.
 * All methods follow assignment specifications precisely.
 */
public class Login {
    
    // User account fields
    private String first_name;
    private String last_name;
    private String user_name;
    private String pass_word;
    private String cell_number;

    /**
     * Constructor sets up Login with user registration data.
     * 
     * @param first_name User first name
     * @param last_name User last name
     * @param user_name Desired username
     * @param pass_word Desired password
     * @param cell_number Cell phone number
     */
    public Login(String first_name, String last_name, String user_name, String pass_word, String cell_number) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.user_name = user_name;
        this.pass_word = pass_word;
        this.cell_number = cell_number;
    }

    /**
     * Check username formatting rules.
     * Rule: Must contain underscore and max 5 characters.
     * 
     * @return boolean result
     */
    public boolean checkUserName() {
        boolean underscoreExists = user_name.contains("_");
        boolean lengthValid = user_name.length() <= 5;
        return underscoreExists && lengthValid;
    }

    /**
     * Check password complexity rules.
     * Rules: 8+ chars, uppercase, digit, special character.
     * 
     * @return boolean result
     */
    public boolean checkPasswordComplexity() {
        boolean upperCaseFound = false;
        boolean digitFound = false;
        boolean specialFound = false;

        if (pass_word.length() < 8) {
            return false;
        }

        for (int i = 0; i < pass_word.length(); i++) {
            char ch = pass_word.charAt(i);
            
            if (Character.isUpperCase(ch)) upperCaseFound = true;
            if (Character.isDigit(ch)) digitFound = true;
            if (!Character.isLetterOrDigit(ch)) specialFound = true;
        }

        return upperCaseFound && digitFound && specialFound;
    }

    /**
     * Check cell phone number format.
     * Format: +27 followed by 9 digits.
     * 
     * @return boolean result
     */
    public boolean checkCellPhoneNumber() {
        return cell_number.matches("^\\+27\\d{9}$");
    }

    /**
     * Register user with validation.
     * 
     * @return String message
     */
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    /**
     * Verify login credentials.
     * 
     * @param enteredUser Username entered
     * @param enteredPass Password entered
     * @return boolean result
     */
    public boolean loginUser(String enteredUser, String enteredPass) {
        return user_name.equals(enteredUser) && pass_word.equals(enteredPass);
    }

    /**
     * Get login status message.
     * 
     * @param enteredUser Username entered
     * @param enteredPass Password entered
     * @return String message
     */
    public String returnLoginStatus(String enteredUser, String enteredPass) {
        if (loginUser(enteredUser, enteredPass)) {
            return "Welcome " + first_name + ", " + last_name + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}
